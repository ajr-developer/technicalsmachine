#data-processing.py
from RestfulClient import get
from binance.client import Client

def format_data_COINMARKETCAP(apiURL):
    """ Pulls in the top 100 cryptos from CoinMarketCap and formats for use in table

    :param apiURL: URL for CoinMarketCap's current API
    :type apiURL: str.

    :returns: Formatted list of top 100 cryptos on CoinMarketCap
    :type returns: list of JSON

    table_data = [
        {   
            'name': str,
            'symbol': str,
            'rank': str,
            'price': str,
            'market_cap': str
        },
        ...
    ]

    """
    # pull in and preliminarily format API data
    apiURL = apiURL
    exchangeData = get(apiURL)
    processedExchangeData = exchangeData['data']
    
    # format for use in table
    table_data = []
    for key in processedExchangeData:
        name = processedExchangeData[key]['name']
        symbol = processedExchangeData[key]['symbol']
        rank = processedExchangeData[key]['rank']
        price = processedExchangeData[key]['quotes']['USD']['price']
        market_cap = processedExchangeData[key]['quotes']['USD']['market_cap']
        current_crypto = {
            'name': name,
            'symbol': symbol,
            'rank': rank,
            'price': price,
            'market_cap': market_cap
        }
        table_data.append(current_crypto)

    return table_data


list = format_data_COINMARKETCAP('https://api.coinmarketcap.com/v2/ticker/?sort=rank')
print(list)